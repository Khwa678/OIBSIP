# Pizza Delivery MERN
server/: Express, MongoDB, JWT, Razorpay
client/: React + Vite
Run: npm install in both folders, configure .env, npm run dev.
Features: Auth, Pizza Builder, Cart, Payment, Admin Dashboard, Inventory.
